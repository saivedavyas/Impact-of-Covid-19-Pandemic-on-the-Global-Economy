# Impact_of_Covid-19_Pandemic_on_the_Global_Economy_Analysis
Studied the spread of covid-19 among the countries and its impact on the global economy. 

The dataset is downloaded from Kaggle.

link - https://www.kaggle.com/datasets/shashwatwork/impact-of-covid19-pandemic-on-the-global-economy

It contains data about:
 
  1.the country code
  
  2.name of all the countries
  
  3.date of the record
  
  4.Human development index of all the countries
  
  5.Daily covid-19 cases
  
  6.Daily deaths due to covid-19 
  
  7.stringency index of the countries
  
  8.the population of the countries 
  
  9.GDP per capita of the countries
